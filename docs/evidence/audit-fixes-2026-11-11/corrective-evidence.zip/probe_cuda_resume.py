"""Reproduce delayed CPU-to-CUDA checkpoint migration, preserving production code."""
import copy
import io
import json
import traceback
from pathlib import Path

import bitsandbytes as bnb
import torch
from lionplus8bit import LionPlus8bit

rows = []
for mode in ("global", "adagc"):
    for size in (17, 4097):
        for move in (True, False):
            bnb.optim.GlobalOptimManager.get_instance().initialize()
            p = torch.nn.Parameter(torch.ones(size, device="cuda"))
            source = LionPlus8bit([p], clipping=mode, adagc_warmup_steps=0)
            p.grad = torch.ones_like(p)
            source.step()
            stream = io.BytesIO()
            torch.save(source.state_dict(), stream)
            stream.seek(0)
            checkpoint = torch.load(stream, map_location="cpu", weights_only=True)
            q = torch.nn.Parameter(p.detach().clone())
            target = LionPlus8bit([q])
            target.load_state_dict(copy.deepcopy(checkpoint), move_to_device=move)
            q.grad = torch.ones_like(q)
            before = q.detach().clone()
            row = dict(mode=mode, size=size, move_to_device=move,
                       loaded_state_device=str(target.state[q]["state1"].device))
            try:
                target.step()
                torch.cuda.synchronize()
                row.update(status="passed", final_state_device=str(target.state[q]["state1"].device))
            except Exception as error:
                row.update(status="failed", error_type=type(error).__name__, error=str(error),
                           traceback=traceback.format_exc(), parameter_unchanged=torch.equal(q, before))
            rows.append(row)
            print({k: v for k, v in row.items() if k != "traceback"}, flush=True)
Path(__file__).with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")
