import json,math,os,statistics,subprocess,sys
from pathlib import Path
out=Path(__file__).parent/'study'
out.mkdir(exist_ok=False)
config=Path('docs/evidence/adagc/study_config.json')
(out/'study_config.json').write_bytes(config.read_bytes())
rows=[]
arms=[('global',8),('adagc',8),('adagc',32)]
for i,seed in enumerate((17,29,43)):
 for strategy,bits in arms[i:]+arms[:i]:
  name=f'{strategy}-{bits}-seed{seed}'
  with (out/f'{name}.log').open('w') as log:
   subprocess.run([sys.executable,'tools/study_clipping.py','--config',str(config),'--strategy',strategy,'--momentum-bits',str(bits),'--seed',str(seed),'--output',str(out/name)],stdout=log,stderr=subprocess.STDOUT,check=True)
  rows.append(json.loads((out/name/'result.json').read_text()))
  print(name,'completed',flush=True)
deltas=[]
for seed in (17,29,43):
 pair={r['strategy']+str(r['momentum_bits']):r for r in rows if r['seed']==seed}
 assert len({r['initial_sha256'] for r in pair.values()})==1
 assert len({r['order_sha256'] for r in pair.values()})==1
 a,b=pair['global8'],pair['adagc8']
 deltas.append((b['validation_bce']-a['validation_bce'])/a['validation_bce'])
mean=statistics.mean(deltas); half=4.3026527299*statistics.stdev(deltas)/math.sqrt(3)
result=dict(results=rows,paired_relative_bce=deltas,mean=mean,ci95=[mean-half,mean+half],quality_margin=.02,quality_status='pass' if mean+half<=.02 else 'fail' if mean-half>.02 else 'inconclusive',order='rotated by seed to balance arm position',production_status='unresolved: substitute subset task')
(out/'aggregate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='results'}),flush=True)
