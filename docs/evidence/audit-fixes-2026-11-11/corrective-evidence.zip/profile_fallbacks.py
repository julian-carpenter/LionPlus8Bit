"""Audit replay of already-unscaled gradients; no production code changes."""
import gc,json,statistics,time
from pathlib import Path
from unittest.mock import patch
import torch
from lionplus8bit import LionPlus8bit

OUT=Path(__file__).parent

def one(mode,case,n=1048576):
    gc.collect();torch.cuda.empty_cache();torch.manual_seed(123)
    p=torch.nn.Parameter(torch.ones(n,device='cuda'))
    q=torch.nn.Parameter(torch.ones(1,device='cuda'))
    opt=LionPlus8bit([p,q],clipping=mode,adagc_warmup_steps=0,max_grad_norm=1)
    p.grad=torch.full_like(p,1e-3);q.grad=torch.full_like(q,1e-3)
    for _ in range(8):opt.step()
    if case in ('tiny','recovered'):
        q.grad.fill_(1e-25);opt.step()
    if case=='recovered':q.grad.fill_(1e-3)
    if case=='zero':q.grad.zero_()
    torch.cuda.synchronize();baseline=torch.cuda.memory_allocated();torch.cuda.reset_peak_memory_stats()
    timings=[]
    for _ in range(20):
        begin=time.perf_counter();opt.step();torch.cuda.synchronize();timings.append((time.perf_counter()-begin)*1000)
    peak=torch.cuda.max_memory_allocated();calls=[];orig=torch.linalg.vector_norm
    def tracked(x,*args,**kwargs):
        calls.append(dict(elements=x.numel(),input_dtype=str(x.dtype),requested_dtype=str(kwargs.get('dtype'))))
        return orig(x,*args,**kwargs)
    with patch.object(torch.linalg,'vector_norm',tracked):
        with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA],profile_memory=True,record_shapes=True) as prof:
            opt.step();torch.cuda.synchronize()
    prof.export_chrome_trace(str(OUT/f'{mode}-{case}.trace.json'))
    events=[]
    for e in prof.key_averages(group_by_input_shape=True):
        if e.key in ('aten::_to_copy','aten::to','aten::index','aten::repeat_interleave','aten::linalg_vector_norm') or 'Synchroniz' in e.key or '_local_scalar_dense' in e.key:
            events.append(dict(name=e.key,count=e.count,shapes=e.input_shapes,cpu_us=e.self_cpu_time_total,device_memory=e.device_memory_usage))
    return dict(mode=mode,case=case,numel=n,median_ms=statistics.median(timings),samples_ms=timings,baseline_allocated=baseline,peak_allocated=peak,extra_peak=peak-baseline,strict_flags=[opt.state[x].get('strict_math',False) for x in (p,q)],state_dtype=str(opt.state[p]['state1'].dtype),norm_calls=calls,events=events)

rows=[]
for mode in ('global','adagc'):
    for case in ('normal','zero','tiny','recovered'):
        r=one(mode,case);rows.append(r);print({k:r[k] for k in ('mode','case','median_ms','extra_peak','strict_flags')},flush=True)
(OUT/'fallback-profile.json').write_text(json.dumps(rows,indent=2)+'\n')
