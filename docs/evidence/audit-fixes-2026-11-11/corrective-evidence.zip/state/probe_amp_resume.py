import copy
import json
import pathlib
import sys
import torch
import bitsandbytes as bnb
from lionplus8bit import LionPlus8bit

ROOT=pathlib.Path(__file__).resolve().parent

def equal(a,b):
    if isinstance(a,torch.Tensor):
        torch.testing.assert_close(a,b,rtol=0,atol=0)
    elif isinstance(a,dict):
        if a.keys()!=b.keys():
            assert a.keys() ^ b.keys() == {'differentiable'}, (a.keys(),b.keys())
            assert a.get('differentiable',False) is False and b.get('differentiable',False) is False
        for k in a.keys() & b.keys(): equal(a[k],b[k])
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b)
        for x,y in zip(a,b): equal(x,y)
    else: assert a==b, (a,b)

def setup(has_added=False):
    bnb.optim.GlobalOptimManager.get_instance().initialize()
    params=torch.nn.ParameterList([
        torch.nn.Parameter(torch.linspace(-0.3,0.3,4097).reshape(1,-1)),
        torch.nn.Parameter(torch.linspace(-0.2,0.2,257).reshape(1,-1)),
        torch.nn.Parameter(torch.ones(1,1)),
    ])
    opt=LionPlus8bit([{'params':[params[0]]},{'params':[params[1]],'weight_decay':0.0}],
                    lr=0.01,clipping='adagc',adagc_warmup_steps=2,max_grad_norm=0.3)
    if has_added: opt.add_param_group({'params':[params[2]],'lr':0.002})
    sch=torch.optim.lr_scheduler.StepLR(opt,step_size=2,gamma=0.5)
    scaler=torch.amp.GradScaler('cpu',init_scale=32,growth_interval=2)
    return params,opt,sch,scaler

def snapshot(parts):
    params,opt,sch,scaler=parts
    return copy.deepcopy({'model':params.state_dict(),'optimizer':opt.state_dict(),
                          'scheduler':sch.state_dict(),'scaler':scaler.state_dict()})

def update(parts,t):
    params,opt,sch,scaler=parts
    if t==3: opt.add_param_group({'params':[params[2]],'lr':0.002})
    opt.zero_grad(set_to_none=True)
    with torch.autocast('cpu',dtype=torch.bfloat16):
        loss=0
        for i,p in enumerate(params):
            if (i==1 and t%2==0) or (i==2 and t<3): continue
            x=torch.sin(torch.arange(p.numel(),dtype=torch.float32)*0.01+t+i).reshape(1,-1)
            loss=loss+torch.nn.functional.linear(x,p).square().mean()
    scaler.scale(loss).backward()
    if t in (1,4): params[0].grad.fill_(float('inf'))
    before=snapshot(parts)
    old_scale=scaler.get_scale()
    scaler.step(opt)
    scaler.update()
    skipped=scaler.get_scale()<old_scale
    if not skipped: sch.step()
    if skipped:
        equal(before['model'],params.state_dict())
        equal(before['optimizer'],opt.state_dict())
        equal(before['scheduler'],sch.state_dict())
    return {'attempt':t,'skipped':skipped,'scale':scaler.get_scale(),
            'adagc_steps':opt._clipping_state.steps if opt._clipping_state else None,
            'history':opt._clipping_state.history.tolist() if opt._clipping_state else None}

if sys.argv[1]=='produce':
    parts=setup()
    trajectory=[]
    for t in range(7):
        trajectory.append(update(parts,t))
        torch.save(snapshot(parts),ROOT/f'amp_checkpoint_{t+1}.pt')
    result={'role':'producer','torch':torch.__version__,'bitsandbytes':bnb.__version__,
            'trajectory':trajectory,'large_momentum_dtype':str(parts[1].state[parts[0][0]]['state1'].dtype)}
else:
    final=torch.load(ROOT/'amp_checkpoint_7.pt',weights_only=True,map_location='cpu')
    splits=[]
    for split in (1,2,3,4,5,6):
        saved=torch.load(ROOT/f'amp_checkpoint_{split}.pt',weights_only=True,map_location='cpu')
        parts=setup(has_added=len(saved['optimizer']['param_groups'])==3)
        params,opt,sch,scaler=parts
        params.load_state_dict(saved['model'])
        opt.load_state_dict(saved['optimizer'])
        sch.load_state_dict(saved['scheduler'])
        scaler.load_state_dict(saved['scaler'])
        equal(saved,snapshot(parts))
        for t in range(split,7): update(parts,t)
        equal(final,snapshot(parts))
        splits.append({'split_after_attempts':split,'bitwise_equal':True,
                       'final_adagc_steps':opt._clipping_state.steps})
    result={'role':'resumer','splits':splits,'metadata_normalization':'Absent differentiable is equivalent to differentiable=False (PyTorch __setstate__ adds this default before dynamic add_param_group).'}
(ROOT/f'amp_{sys.argv[1]}_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
