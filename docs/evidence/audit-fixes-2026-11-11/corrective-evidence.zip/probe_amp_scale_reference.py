"""Independent CUDA AMP scale/skip control with real uint8 momentum.

Power-of-two inputs and scaling isolate optimizer semantics from FP16 backward
rounding. The reference uses the same autocast forward without GradScaler.
"""
import copy
import json
from pathlib import Path

import bitsandbytes as bnb
import torch
from lionplus8bit import LionPlus8bit


def equal(a, b):
    if isinstance(a, torch.Tensor):
        return isinstance(b, torch.Tensor) and torch.equal(a, b)
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if isinstance(a, (tuple, list)):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


bnb.optim.GlobalOptimManager.get_instance().initialize()
runs = []
for scale in (None, 16, 1024):
    model = torch.nn.Linear(128, 64, bias=False).cuda()
    with torch.no_grad():
        model.weight.fill_(0.125)
    opt = LionPlus8bit(model.parameters(), lr=1 / 256, betas=(0.5, 0.5),
                      weight_decay=0, clipping="adagc", max_grad_norm=1,
                      adagc_warmup_steps=2)
    scaler = None if scale is None else torch.amp.GradScaler("cuda", init_scale=scale)
    runs.append((model, opt, scaler))
x = torch.ones(8, 128, device="cuda")
rows = []
for attempt in range(6):
    for i, (model, opt, scaler) in enumerate(runs):
        opt.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.float16):
            loss = model(x).float().square().mean()
        (scaler.scale(loss) if scaler else loss).backward()
        if scaler and attempt in (0, 3):
            model.weight.grad.view(-1)[0] = float("inf")
        if scaler and i == 1:
            scaler.unscale_(opt)
        before = copy.deepcopy(opt.state_dict())
        weights = model.weight.detach().clone()
        if scaler:
            scaler.step(opt)
            scaler.update()
        elif attempt not in (0, 3):
            opt.step()
        if attempt in (0, 3):
            assert equal(before, opt.state_dict())
            assert torch.equal(weights, model.weight)
    reference = runs[0]
    for model, opt, scaler in runs[1:]:
        assert torch.equal(reference[0].weight, model.weight)
        assert equal(reference[1].state_dict(), opt.state_dict())
    rows.append(dict(attempt=attempt, skipped=attempt in (0, 3),
                     state_equal=True, parameters_equal=True,
                     adagc_steps=reference[1]._clipping_state.steps if reference[1]._clipping_state else 0))

result = dict(rows=rows, parameter_dtype=str(runs[0][0].weight.dtype),
              momentum_dtype=str(runs[0][1].state[runs[0][0].weight]["state1"].dtype),
              initial_loss_scales=[16, 1024], explicit_unscale_scale=16,
              overflow_injection_scales=[16, 1024], final_status="passed")
print(json.dumps(result, indent=2))
Path(__file__).with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
