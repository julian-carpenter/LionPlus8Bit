"""Real CUDA FP16 autocast + GradScaler with FP32 weights and uint8 momentum.

The auxiliary scalar explicitly exercises zero/tiny gradients. Timings cover
scaler.step/update and synchronization, excluding forward and backward.
"""
import copy
import gc
import json
import statistics
import time
from pathlib import Path

import bitsandbytes as bnb
import torch
from lionplus8bit import LionPlus8bit


def equal(a, b):
    if isinstance(a, torch.Tensor):
        return isinstance(b, torch.Tensor) and torch.equal(a, b)
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def run(case):
    gc.collect()
    torch.cuda.empty_cache()
    bnb.optim.GlobalOptimManager.get_instance().initialize()
    torch.manual_seed(771)
    model = torch.nn.Linear(1024, 1024, bias=False).cuda()
    auxiliary = torch.nn.Parameter(torch.ones((), device="cuda"))
    params = list(model.parameters()) + [auxiliary]
    opt = LionPlus8bit(params, clipping="adagc", adagc_warmup_steps=2, max_grad_norm=1.0)
    scaler = torch.amp.GradScaler("cuda", init_scale=32, growth_interval=1000)
    x = torch.randn(8, 1024, device="cuda")
    y = torch.randn(8, 1024, device="cuda")

    def backward(strength):
        opt.zero_grad(set_to_none=True)
        with torch.autocast("cuda", dtype=torch.float16):
            pred = model(x)
            main = (pred.float() - y).square().mean()
        loss = main + auxiliary * strength
        scaler.scale(loss).backward()
        return float(main.detach())

    for _ in range(8):
        backward(1e-3)
        scaler.step(opt)
        scaler.update()
    if case == "recovered":
        backward(1e-25)
        scaler.step(opt)
        scaler.update()
    times, peaks, losses = [], [], []
    for _ in range(12):
        losses.append(backward(0 if case == "zero" else 1e-3))
        torch.cuda.synchronize()
        before = torch.cuda.memory_allocated()
        torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        scaler.step(opt)
        scaler.update()
        torch.cuda.synchronize()
        times.append((time.perf_counter() - start) * 1000)
        peaks.append(torch.cuda.max_memory_allocated() - before)
    # Overflow must skip *all* optimizer state, including sticky strict metadata.
    backward(1e-3)
    params[0].grad.view(-1)[0] = float("inf")
    old_state = copy.deepcopy(opt.state_dict())
    old_params = [p.detach().clone() for p in params]
    scaler.step(opt)
    scaler.update()
    row = dict(case=case, parameter_dtype=str(params[0].dtype), autocast_dtype="torch.float16",
               momentum_dtype=str(opt.state[params[0]]["state1"].dtype),
               strict_flags=[opt.state[p].get("strict_math", False) for p in params],
               native_steps=[opt.state[p]["step"] for p in params], adagc_steps=opt._clipping_state.steps,
               overflow_optimizer_unchanged=equal(old_state, opt.state_dict()),
               overflow_parameters_unchanged=all(torch.equal(a, b) for a, b in zip(old_params, params)),
               scaler_after_overflow=scaler.get_scale(), median_ms=statistics.median(times),
               median_extra_peak_bytes=statistics.median(peaks), samples_ms=times,
               extra_peak_bytes=peaks, loss_samples=losses)
    print({k: v for k, v in row.items() if k not in ("samples_ms", "extra_peak_bytes", "loss_samples")}, flush=True)
    return row


rows = [run(case) for case in ("normal", "zero", "recovered")]
Path(__file__).with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")
