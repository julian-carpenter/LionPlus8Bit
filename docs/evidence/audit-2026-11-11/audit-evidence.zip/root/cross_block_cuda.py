# CUDA adaptation of perf/cross_block_probe.py; only default device and output path changed.
"""Reproduce global-normalization loss between independently quantized blocks."""
import json
import os
from pathlib import Path

import torch
import bitsandbytes as bnb
from lionplus8bit import LionPlus8bit

torch.set_num_threads(1)
assert torch.cuda.is_available()
torch.set_default_device('cuda')
assert torch.tensor(1e-39, dtype=torch.float32).item() > 0
OUT=Path(__file__).resolve().parent

def blockwise_quantize_reference(momentum, code):
    blocks=momentum.reshape(-1,256)
    peaks=blocks.abs().amax(1)
    divisors=torch.where(peaks>0,peaks,torch.ones_like(peaks))
    normalized=(blocks/divisors[:,None]).contiguous()
    quantized, qs=bnb.functional.quantize_blockwise(normalized,code=code,blocksize=256)
    scales=qs.absmax*divisors
    decoded=code[quantized.long()].reshape_as(blocks)*scales[:,None]
    return decoded.reshape_as(momentum),quantized.reshape_as(momentum),scales

def run(mode):
    p=torch.nn.Parameter(torch.zeros(4096))
    opt=LionPlus8bit([p],clipping=mode,adagc_warmup_steps=0,max_grad_norm=float('inf'),
                    betas=(.9,.9),lr=.1,weight_decay=0,min_8bit_size=4096)
    reference_parameter=torch.zeros_like(p)
    reference_momentum=torch.zeros_like(p)
    rows=[]
    for step in range(3):
        g=torch.zeros_like(p)
        g[:256]=1e10
        g[256:512]=1e-39 if step==0 else -1e-40 if step==1 else 0
        before=p.detach().clone()
        expected_direction=(reference_momentum*.9+g*.1).sign()
        reference_parameter.add_(expected_direction,alpha=-.1)
        unquantized=reference_momentum*.9+g*.1
        p.grad=g
        opt.step()
        state=opt.state[p]
        reference_momentum,ref_codes,ref_scales=blockwise_quantize_reference(unquantized,state['qmap1'])
        actual=bnb.functional.dequantize_blockwise(state['state1'],code=state['qmap1'],absmax=state['absmax1'],blocksize=256)
        actual_direction=(before-p.detach()).sign()
        row={'step':step+1,'strategy':mode,'strict_math':state.get('strict_math',False),
             'parameter_small_block':float(p[256]),'expected_parameter_small_block':float(reference_parameter[256]),
             'momentum_small_block':float(actual[256]),'expected_momentum_small_block':float(reference_momentum[256]),
             'absmax_small_block':float(state['absmax1'][1]),'reference_absmax_small_block':float(ref_scales[1]),
             'sign_disagreements':int((actual_direction!=expected_direction).sum()),
             'disagreements_in_small_block':int((actual_direction[256:512]!=expected_direction[256:512]).sum()),
             'raw_gradient_small_block':float(g[256]),
             'large_block_absmax':float(state['absmax1'][0]),
             'globally_normalized_small':float((unquantized/unquantized.abs().max())[256]),
             'grad_preserved':torch.equal(g,p.grad),
             'last_clipping':opt.last_clipping}
        rows.append(row)
    assert rows[0]['momentum_small_block']==0.0
    assert rows[0]['expected_momentum_small_block']>0.0
    assert rows[1]['disagreements_in_small_block']==256
    return rows

result={'torch':torch.__version__,'bitsandbytes':bnb.__version__,'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),
        'cuda_available':torch.cuda.is_available(),'description':'Uniform blocks are exactly representable by per-block absmax with qmap endpoint codes; FP32 subnormals survive in the per-block reference.',
        'runs':[run('global'),run('adagc')]}
(OUT/'cross_block_cuda.json').write_text(json.dumps(result,indent=2)+'\n')
for run in result['runs']:
 for r in run:
  print(json.dumps(r))
