"""Independent, CPU-only AMP/AdaGC audit probes; never edits the target repo."""

import copy
import inspect
import json
import math
from pathlib import Path
import sys

import bitsandbytes as bnb
import torch

from lionplus8bit import LionPlus8bit


OUT = Path(__file__).resolve().parent
torch.set_num_threads(1)


def exact(a, b):
    if isinstance(a, torch.Tensor):
        torch.testing.assert_close(a, b, rtol=0, atol=0, equal_nan=True)
    elif isinstance(a, dict):
        assert a.keys() == b.keys()
        for key in a:
            exact(a[key], b[key])
    elif isinstance(a, (list, tuple)):
        assert len(a) == len(b)
        for x, y in zip(a, b):
            exact(x, y)
    else:
        assert a == b, (a, b)


def effective_history(opt):
    state = opt._clipping_state
    if state is None:
        return None
    return [state.exceptions.get(i, float(v)) for i, v in enumerate(state.history)]


def finite_norm_overflow():
    rows = []
    for dtype in (torch.float32, torch.bfloat16):
        for mode in ("global", "adagc"):
            for batched in (True, False):
                for warmup in (0, 1):
                    p = torch.nn.Parameter(torch.ones(2, dtype=dtype))
                    opt = LionPlus8bit(
                        [p], clipping=mode, adagc_warmup_steps=warmup,
                        max_grad_norm=1, betas=(0, 0), weight_decay=0,
                        batched_norm=batched,
                    )
                    p.grad = torch.full_like(p, 1e20)
                    row = dict(mode=mode, dtype=str(dtype), batched_norm=batched,
                               warmup=warmup, grad_finite=bool(torch.isfinite(p.grad).all()),
                               norm32=str(float(p.grad.float().norm())),
                               norm64=float(p.grad.double().norm()))
                    try:
                        opt.step()
                        row.update(result="updated", momentum=opt.state[p]["state1"].tolist())
                    except Exception as error:
                        row.update(result=type(error).__name__, error=str(error),
                                   native_state_count=len(opt.state),
                                   history_allocated=opt._clipping_state is not None)
                    rows.append(row)
    return rows


def minimum_threshold_boundary():
    rows = []
    for mode in ("global", "adagc"):
        for phase in ("bootstrap", "warmup", "adaptive"):
            for threshold in (2 ** -149, 2 ** -148, 2 ** -150):
                p = torch.nn.Parameter(torch.ones(1))
                opt = LionPlus8bit([p], clipping=mode,
                                  adagc_warmup_steps=int(phase == "warmup"),
                                  adagc_factor=1, max_grad_norm=threshold,
                                  betas=(0, 0), weight_decay=0)
                if phase == "adaptive":
                    opt.param_groups[0]["max_grad_norm"] = 1
                    p.grad = torch.tensor([threshold])
                    opt.step()
                    opt.param_groups[0]["max_grad_norm"] = threshold
                p.grad = torch.tensor([49.])
                n = p.grad.double().norm()
                scale = threshold / n
                row = dict(mode=mode, phase=phase, threshold=threshold,
                           reconstructed_clipped_norm=float(scale * n),
                           represented_gradient=float((p.grad.double() * scale).float()[0]))
                try:
                    opt.step()
                    row.update(result="updated", momentum=opt.state[p]["state1"].tolist())
                except Exception as error:
                    row.update(result=type(error).__name__, error=str(error))
                rows.append(row)
    return rows


def amp_invariance():
    torch.manual_seed(812)
    models = [torch.nn.Linear(4, 2)]
    models.extend(copy.deepcopy(models[0]) for _ in range(2))
    opts = [LionPlus8bit(m.parameters(), clipping="adagc", adagc_warmup_steps=1,
                        max_grad_norm=0.4, lr=0.01, weight_decay=0,
                        betas=(0.6, 0.8)) for m in models]
    scalers = [torch.amp.GradScaler("cpu", init_scale=scale, growth_interval=2)
               for scale in (16, 1024)]
    assert not getattr(opts[0], "_step_supports_amp_scaling", False)
    rows = []
    for step in range(6):
        x = torch.randn(5, 4)
        y = torch.randn(5, 2) * (20 if step == 4 else 1)
        snapshots = [copy.deepcopy((m.state_dict(), o.state_dict(), o.last_clipping))
                     for m, o in zip(models, opts)]
        gradients = []
        for i, (model, opt) in enumerate(zip(models, opts)):
            opt.zero_grad(set_to_none=True)
            with torch.autocast("cpu", dtype=torch.bfloat16):
                output = model(x)
                loss = (output - y).square().mean()
                if step == 3:
                    loss = loss * 0
            (scalers[i].scale(loss) if i < 2 else loss).backward()
            if step in (0, 2):
                next(model.parameters()).grad.fill_(float("inf"))
            gradients.append([p.grad for p in model.parameters()])
        scalers[0].unscale_(opts[0])
        for scaler, opt in zip(scalers, opts):
            scaler.step(opt)
            scaler.update()
        if step not in (0, 2):
            opts[2].step()
        for model, opt, saved in zip(models, opts, snapshots):
            if step in (0, 2):
                exact((model.state_dict(), opt.state_dict(), opt.last_clipping), saved)
        for i in range(2):
            exact(models[i].state_dict(), models[2].state_dict())
            exact(opts[i].state_dict(), opts[2].state_dict())
            if step not in (0, 2):
                for p, q, original in zip(models[i].parameters(), models[2].parameters(), gradients[i]):
                    assert p.grad is original
                    exact(p.grad, q.grad)
        rows.append(dict(step=step, overflow=step in (0, 2),
                         zero_gradient=step == 3,
                         completed_updates=opts[0]._clipping_state.steps if opts[0]._clipping_state else 0,
                         histories=effective_history(opts[0]),
                         scales=[s.get_scale() for s in scalers]))
    return dict(result="passed", dtype="CPU BF16 autocast with FP32 parameters",
                comparison="bitwise: two scaled paths versus unscaled autocast reference",
                steps=rows)


def half_precision():
    rows = []
    for dtype in (torch.float16, torch.bfloat16):
        for master in (True, False):
            for threshold in (1e-7, 1e-10):
                p = torch.nn.Parameter(torch.ones(2, dtype=dtype))
                opt = LionPlus8bit([p], clipping="adagc", adagc_warmup_steps=0,
                                  max_grad_norm=threshold, master_weights=master,
                                  betas=(0, 0), lr=.01, weight_decay=0)
                p.grad = torch.ones_like(p)
                original = p.grad
                opt.step()
                assert p.grad is original
                exact(p.grad, torch.ones_like(p))
                actual_norm = float(opt.state[p]["state1"].double().norm())
                history = effective_history(opt)[0]
                assert math.isclose(history, actual_norm, rel_tol=1e-6, abs_tol=0)
                rows.append(dict(dtype=str(dtype), master_weights=master,
                                 threshold=threshold, parameter=p.tolist(),
                                 actual_clipped_norm=actual_norm, history=history,
                                 initialized=bool(opt._clipping_state.initialized[0]),
                                 master_dtype=str(opt.state[p]["master_weight"].dtype) if master else None))
    for dtype in (torch.float16, torch.bfloat16):
        p = torch.nn.Parameter(torch.ones(2, dtype=dtype))
        opt = LionPlus8bit([p], clipping="adagc")
        scaler = torch.amp.GradScaler("cpu", init_scale=16)
        scaler.scale(p.float().sum()).backward()
        try:
            scaler.step(opt)
            rows.append(dict(dtype=str(dtype), scaler="enabled", result="updated"))
            assert dtype == torch.bfloat16
        except ValueError as error:
            assert dtype == torch.float16 and "unscale FP16" in str(error)
            assert opt._clipping_state is None and not opt.state
            rows.append(dict(dtype=str(dtype), scaler="enabled", result=str(error)))
    return rows


def accumulation():
    # Exact representable samples isolate optimizer semantics from GEMM ordering.
    p = torch.nn.Parameter(torch.tensor([1., -1.]))
    q = torch.nn.Parameter(p.detach().clone())
    a = LionPlus8bit([p], clipping="adagc", adagc_warmup_steps=1,
                    max_grad_norm=0.3, betas=(0.6, 0.8), weight_decay=0)
    b = LionPlus8bit([q], clipping="adagc", adagc_warmup_steps=1,
                    max_grad_norm=0.3, betas=(0.6, 0.8), weight_decay=0)
    sa, sb = [torch.amp.GradScaler("cpu", init_scale=32) for _ in range(2)]
    rows = []
    for chunks in ((2, 2), (3, 1), (1,)):
        a.zero_grad(set_to_none=True)
        b.zero_grad(set_to_none=True)
        weights = torch.tensor([[1., -2.], [3., 1.], [-2., 4.], [2., -1.]])[:sum(chunks)]
        sa.scale((p * weights).sum(1).mean()).backward()
        start = 0
        for count in chunks:
            micro = (q * weights[start:start + count]).sum(1).mean()
            sb.scale(micro * (count / len(weights))).backward()
            start += count
        sa.step(a)
        sb.step(b)
        sa.update()
        sb.update()
        exact(p, q)
        exact(p.grad, q.grad)
        exact(a.state_dict(), b.state_dict())
        rows.append(dict(chunks=chunks, gradient=p.grad.tolist(), history=effective_history(a)))
    return dict(result="passed", comparison="bitwise parameters, momentum, history, counter, gradient", steps=rows)


def closure_and_zero():
    p = torch.nn.Parameter(torch.tensor([2.]))
    opt = LionPlus8bit([p], clipping="adagc", adagc_warmup_steps=1,
                      lr=0.1, betas=(0.6, 0.8), weight_decay=0.5, max_grad_norm=1)
    calls = []

    def closure():
        assert torch.is_grad_enabled()
        calls.append(1)
        opt.zero_grad(set_to_none=True)
        loss = p.square().sum()
        loss.backward()
        return loss

    with torch.no_grad():
        loss = opt.step(closure)
    assert float(loss) == 4 and calls == [1]
    first = copy.deepcopy(opt.state_dict())
    opt.zero_grad(set_to_none=True)
    opt.step()
    exact(first, opt.state_dict())
    before_zero = float(p.detach())
    p.grad = torch.zeros_like(p)
    opt.step()
    assert opt._clipping_state.steps == 2 and opt.state[p]["step"] == 2
    assert math.isclose(effective_history(opt)[0], 0.99, rel_tol=1e-6)
    assert float(p.detach()) < before_zero

    scaler = torch.amp.GradScaler("cpu", init_scale=16)
    scaler.scale(p.sum()).backward()
    try:
        scaler.step(opt, closure=closure)
        raise AssertionError("GradScaler unexpectedly accepted a closure")
    except RuntimeError as error:
        assert "Closure use" in str(error)
    return dict(result="passed", closure_calls=len(calls), completed_updates=2,
                no_gradients="no state change", zero_gradient="history decayed; momentum and weight decay updated",
                scaler_closure="rejected upstream before closure execution")


def tiny_history():
    p = torch.nn.Parameter(torch.ones(1))
    opt = LionPlus8bit([p], clipping="adagc", adagc_warmup_steps=0,
                      adagc_beta=0.5, max_grad_norm=1, betas=(0, 0), weight_decay=0)
    rows = []
    for value in (2 ** -149, 0., 1.):
        p.grad = torch.full_like(p, value)
        opt.step()
        rows.append(dict(gradient=value, history=effective_history(opt)[0],
                         initialized=bool(opt._clipping_state.initialized[0]),
                         scale=opt.last_clipping["scales"][0]))
    assert rows[0]["initialized"]
    assert not rows[1]["initialized"]
    assert rows[2]["initialized"] and rows[2]["scale"] == 1
    return dict(result="passed", steps=rows)


def main():
    results = dict(environment=dict(python=sys.version, torch=torch.__version__,
                                   bitsandbytes=bnb.__version__,
                                   optimizer_source=inspect.getfile(LionPlus8bit),
                                   cuda_available=torch.cuda.is_available()))
    assert not torch.cuda.is_available(), "This audit is CPU-only"
    for name, probe in (
        ("finite_norm_overflow", finite_norm_overflow),
        ("minimum_threshold_boundary", minimum_threshold_boundary),
        ("amp_invariance", amp_invariance),
        ("half_precision", half_precision),
        ("accumulation", accumulation),
        ("closure_and_zero", closure_and_zero),
        ("tiny_history", tiny_history),
    ):
        try:
            results[name] = probe()
            print(name, "completed", flush=True)
        except Exception as error:
            import traceback
            results[name] = dict(result="probe assertion/error", error=repr(error), traceback=traceback.format_exc())
            print(name, repr(error), flush=True)
        (OUT / "probe_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
