Independent AMP and AdaGC audit, 2026-11-11

Revision: `64205431d701415de6aaa8355bcc536f81626cd5` in `/abyss/home/ml/lion_8bit/LionPlus8Bit`. No repository fixes were made, and prior audit reports were not used as evidence. All probes set `CUDA_VISIBLE_DEVICES=''`; no GPU behavior is claimed from these executions.

Two defects were confirmed. The CPU finite-norm overflow rejection is the higher-priority finding. The minimum-FP32 threshold rejection is an extreme boundary issue and should rank lower. The independent AMP controls found no defect in ordinary unscaling, overflow skips, accumulation, or AdaGC history updates.

1. **P2: finite gradients with an overflowing FP32 norm are rejected before CPU AdaGC can recover in FP64.**

   The initial norms are computed in FP32 at `_optimizer.py:187-194`. `_adagc_step` calls `prepare_clipping` at line 261. On CPU, `_clipping.py:74-75` immediately rejects any nonfinite input norm. Consequently, the intended recovery at `_optimizer.py:265-274` is unreachable when a finite gradient's FP32 reduction overflows. The error conflates a reduction overflow with nonfinite gradient elements.

   Minimal reproduction:

   ```python
   import torch
   from lionplus8bit import LionPlus8bit

   p = torch.nn.Parameter(torch.ones(2))
   opt = LionPlus8bit([p], clipping="adagc", adagc_warmup_steps=0,
                     max_grad_norm=1, betas=(0, 0), weight_decay=0)
   p.grad = torch.tensor([1e20, 1e20])
   opt.step()
   ```

   Every gradient element is finite. The FP32 norm is infinity; the FP64 norm is `1.4142135907151756e20`. AdaGC raises `RuntimeError: Non-finite AdaGC gradient norm`, with no native or clipping state created. Global mode succeeds and stores momentum `[0.7071067690849304, 0.7071067690849304]`. The defect reproduced for FP32 and BF16 parameter/gradient storage, `batched_norm=True/False`, and warmup lengths zero and one. CPU support and extreme-norm recovery are stated in README lines 257 and 448-449.

   Proposed correction: recover/validate norms before calling a preparation function that rejects them, or move nonfinite rejection to the optimizer after its FP64 fallback. Preserve atomic rejection for genuinely nonfinite gradient elements. Do not simply remove gradient validation.

   Acceptance tests: repeat the minimal case for both norm modes, warmup and bootstrap, FP32 and actual BF16 parameters; require finite correct momentum/history and preserved gradient identity/values. Also run after establishing history, and retain NaN/+Inf/-Inf tests asserting that parameters, native state, history, and counters do not change. Add a CPU AMP case whose unscaled gradients are finite but their FP32 norm overflows, since GradScaler's elementwise nonfinite checks do not classify this as an overflow skip.

2. **P3: reconstructing a clipped norm falsely rejects the exact minimum positive FP32 threshold.**

   `_clipping.py:95-102` derives a scale and reconstructs the clipped observation with `h * n`. `_optimizer.py:277-279` compares that reconstructed floating-point product strictly against `2**-149`. A representable intended threshold can reconstruct one FP64 rounding step below the threshold and be rejected, despite the actual FP64-work/FP32-output gradient being representable.

   Minimal reproduction:

   ```python
   p = torch.nn.Parameter(torch.ones(1))
   opt = LionPlus8bit([p], clipping="adagc", adagc_warmup_steps=0,
                     max_grad_norm=2**-149, betas=(0, 0), weight_decay=0)
   p.grad = torch.tensor([49.])
   opt.step()
   ```

   The requested threshold is `1.401298464324817e-45`. The reconstructed norm is `1.4012984643248169e-45`. The actual scaled gradient converted to FP32 is exactly `1.401298464324817e-45`, yet AdaGC raises `ValueError: AdaGC clipping threshold is below FP32 gradient representability`. Global clipping succeeds. The defect also reproduces during warmup and with established minimum-valued history plus `adagc_factor=1`. The neighboring threshold `2**-148` succeeds, while a genuinely below-minimum threshold `2**-150` is correctly rejected.

   Proposed correction: make representability validation depend on the intended per-tensor clipping bound, without reconstructing that bound from the rounded coefficient. Retain the explicit rejection of genuinely below-minimum bounds. The existing fallback subsequently measures the actual scaled gradient at `_optimizer.py:506-515` and corrects history at lines 306-315; the false pre-update rejection currently prevents this path from running.

   Acceptance tests: the scalar-49 case must update with nonzero momentum exactly `2**-149`, initialize positive history, and preserve the original gradient, for bootstrap, warmup, and adaptive history. Neighboring valid and invalid bounds must keep their present classification. Execute on CPU and CUDA before claiming backend coverage; this audit executed CPU only.

The controls below passed using the actual optimizer and bitsandbytes CPU backend:

- FP32 parameters under CPU BF16 autocast, with GradScaler initial scales 16 and 1024, matched an unscaled autocast reference bitwise in parameters, gradients, native momentum, AdaGC history, and counters. One scaled path used explicit `unscale_`; the other used implicit unscaling in `step`.
- Overflow before initialization and at the warmup boundary preserved weights, the entire optimizer state, and `last_clipping`. Loss scales decreased, and only successful optimizer calls advanced the warmup counter.
- An active zero gradient decayed established history and still applied momentum/weight decay. No active gradients left state unchanged. History at `2**-149` with beta 0.5 became unseeded after a zero observation and correctly bootstrapped on the next positive gradient.
- Full batches versus accumulated chunks `(2,2)`, `(3,1)`, and a partial final batch `(1,)` produced bitwise-identical gradients, weights, momentum, history, and counters with loss scaling.
- A direct AdaGC closure ran once with gradient recording enabled, returned the loss, and completed one update. Enabled GradScaler rejected a keyword closure upstream before calling it; this is the local PyTorch contract, not a LionPlus8bit defect.
- Actual FP16 and BF16 parameter storage used FP32 masters by default. At thresholds `1e-7` and `1e-10`, retained history matched the norm of the gradient actually entering momentum within FP32 storage accuracy. With masters disabled, FP16 clipping at `1e-10` rounded to zero and left history unseeded, as the implementation's observed-gradient correction intends. Actual FP16 gradients were rejected by ordinary GradScaler before optimizer initialization; actual BF16 gradients were accepted.
- Existing `test_adagc_reference.py` and `test_adagc_optimizer.py`: **21 passed in 2.39s**.

Specific test gaps:

- Existing large-finite-gradient and extreme-ratio regressions exercise global mode (`tests/test_compatibility.py:288-309`, `tests/test_default_cpu.py:77-84`), leaving the AdaGC early-rejection path uncovered.
- `tests/test_adagc_cuda.py:48-82` compares two instances of the same implementation, asserting model proximity and the final counter, but does not compare the AdaGC history, momentum, or unscaled gradients to an independent unscaled reference. A shared history-scaling error could pass. The CPU probe supplies this independent control; it should be repeated on CUDA with FP16 autocast and quantized momentum.
- Actual-half replay at `tests/test_adagc_cuda.py:10-45` uses master weights by default and infers ideal clipped history; it does not exercise the no-master rounded-observation correction at `_optimizer.py:506-515` and 306-315.
- The existing direct closure test (`tests/test_compatibility.py:200-217`) covers global mode only. The CPU probe verifies AdaGC closure/no-gradient/zero-gradient semantics, which can be retained as a focused regression.

Reproducible artifacts: `probe_amp.py`, `probe_results.json`, and `probe_stdout.log` in this directory. The result JSON contains all individual norm-overflow and threshold cases plus the passed control traces. Runtime: Python 3.12.3, PyTorch `2.13.0a0+9186a08b2c.nv26.07`, bitsandbytes 0.50.2. Imported optimizer source was verified to be the requested repository's `src/lionplus8bit/_optimizer.py`.

Run the probes from any directory:

```bash
CUDA_VISIBLE_DEVICES='' PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/tmp/lionplus-adagc-dev:/abyss/home/ml/lion_8bit/verification_20261111/deps:/abyss/home/ml/lion_8bit/LionPlus8Bit/src \
python /abyss/home/ml/lion_8bit/audit_20261111_fresh/amp/probe_amp.py
```

The probe script records observed failures without changing implementation code; its process exit code alone is not a pass/fail verdict. Inspect each JSON case and the explicit `result` fields.
