import copy
import json
import pathlib
import torch
import bitsandbytes as bnb
from lionplus8bit import LionPlus8bit

ROOT = pathlib.Path('/abyss/home/ml/lion_8bit/audit_20261111_fresh/state')
manager = bnb.optim.GlobalOptimManager.get_instance()
results = {}

def fresh():
    manager.initialize()

def p(value=1.0, dtype=torch.float32):
    return torch.nn.Parameter(torch.tensor([value], dtype=dtype))

def options(**extra):
    return dict(lr=0.1, weight_decay=0, clipping='adagc', adagc_warmup_steps=1, **extra)

fresh()
x = p()
manager.override_config(x, 'lr', 0.125)
source = LionPlus8bit([x], **options())
saved = copy.deepcopy(source.state_dict())
y, z = p(), p()
a, b = LionPlus8bit([y]), LionPlus8bit([z])
a.load_state_dict(saved)
b.load_state_dict(saved)
manager.override_config(y, 'lr', 0.5)
y.grad = torch.ones_like(y)
z.grad = torch.ones_like(z)
a.step()
b.step()
results['override_alias'] = {
    'checkpoint_lr_after_target_override': saved['lionplus_config']['overrides'][0][0]['lr'],
    'second_optimizer_lr_after_first_override': b.get_config(0,0,b.param_groups[0])['lr'],
    'target_parameter': y.item(), 'independent_target_parameter': z.item(),
    'expected_checkpoint_lr': 0.125, 'expected_independent_parameter': 0.875,
    'shared_checkpoint_object': manager.pid2config[id(y)] is saved['lionplus_config']['overrides'][0][0],
    'shared_between_optimizers': manager.pid2config[id(y)] is manager.pid2config[id(z)],
}

fresh()
x = p()
source = LionPlus8bit([x], **options())
x.grad = torch.ones_like(x)
source.step()
saved = copy.deepcopy(source.state_dict())
y = torch.nn.Parameter(x.detach().clone())
manager.override_config(y, 'lr', 0.7)
manager.register_parameters([y])
target = LionPlus8bit([y], **options())
target.load_state_dict(saved)
y.grad = torch.ones_like(y)
before = y.item()
target.step()
results['index_override_survives_load'] = {
    'saved_override': saved['lionplus_config']['overrides'][0][0],
    'saved_group_lr': saved['param_groups'][0]['lr'],
    'target_pid_override': manager.pid2config[id(y)],
    'target_index_override': manager.index2config[(0,0)],
    'effective_lr': target.get_config(0,0,target.param_groups[0])['lr'],
    'parameter_before': before, 'parameter_after': y.item(),
    'expected_parameter_after': before - 0.1,
    'adagc_steps': target._clipping_state.steps,
}

roundtrip=copy.deepcopy(target.state_dict())
roundtrip_parameter=y.detach().clone()
effective_before_save=target.get_config(0,0,target.param_groups[0])['lr']
y.grad=torch.ones_like(y)
target.step()
uninterrupted_value=y.item()
torch.save({'optimizer':roundtrip,'parameter':roundtrip_parameter,
            'expected_uninterrupted':uninterrupted_value}, ROOT/'split_override_checkpoint.pt')
fresh()
z=torch.nn.Parameter(roundtrip_parameter)
resumed=LionPlus8bit([z])
resumed.load_state_dict(roundtrip)
z.grad=torch.ones_like(z)
resumed.step()
results['split_override_serialization']={
 'effective_lr_before_save':effective_before_save,
 'serialized_override':roundtrip['lionplus_config']['overrides'][0][0],
 'effective_lr_after_fresh_manager_load':resumed.get_config(0,0,resumed.param_groups[0])['lr'],
 'uninterrupted_next_parameter':uninterrupted_value,
 'fresh_resumed_next_parameter':z.item(),
}

fresh()
x=torch.nn.Parameter(torch.ones(1,1))
source=LionPlus8bit([x], **options())
manager.override_config(x,'lr',0.125)
x.grad=torch.ones_like(x)
source.step()
saved=copy.deepcopy(source.state_dict())
module=torch.nn.Linear(1,1,bias=False)
with torch.no_grad(): module.weight.fill_(x.item())
manager.register_module_override(module, 'weight', {'lr': 0.7})
target=LionPlus8bit([module.weight], **options())
target.load_state_dict(saved)
before=target.get_config(0,0,target.param_groups[0])['lr']
module.weight.grad=torch.ones_like(module.weight)
target.step()
results['module_override_reapplied_on_resume']={
    'saved_lr': 0.125, 'effective_lr_immediately_after_load': before,
    'effective_lr_after_first_step': target.get_config(0,0,target.param_groups[0])['lr'],
    'parameter_after': module.weight.item(), 'expected_parameter_after': x.item() - 0.125,
}

fresh()
x=p()
source=LionPlus8bit([x], **options())
x.grad=torch.ones_like(x)
source.step()
saved=copy.deepcopy(source.state_dict())
y=p()
target=LionPlus8bit([y])
events=[]
target.register_load_state_dict_pre_hook(lambda *args: events.append('pre'))
target.register_load_state_dict_post_hook(lambda *args: events.append('post'))
target.load_state_dict(saved)
results['load_hooks']={'events':events,'expected':['pre','post']}
post_keys=[]
target.register_state_dict_post_hook(lambda opt, data: post_keys.append(sorted(data)))
target.state_dict()
results['state_dict_post_hook_keys'] = {'observed':post_keys}

fresh()
x=p(dtype=torch.bfloat16)
opt=LionPlus8bit([x], lr=0.1,weight_decay=0,max_grad_norm=100)
x.grad=torch.ones_like(x);opt.step()
first_master=opt.state[x]['master_weight'].item()
x.grad=None
x.data=x.data.float()
x.grad=torch.ones_like(x);opt.step()
fp32_parameter=x.item()
x.grad=None
x.data=x.data.bfloat16()
x.grad=torch.ones_like(x);opt.step()
results['live_dtype_switch']={
 'first_master':first_master,'after_fp32_update':fp32_parameter,
 'after_returning_to_bfloat16':x.item(),'final_master':opt.state[x]['master_weight'].item(),
 'expected_monotonic_parameter':float(torch.tensor(fp32_parameter - 0.1,dtype=torch.bfloat16)),
}

fresh()
x=p()
opt=LionPlus8bit([x], **options())
x.grad=torch.ones_like(x); opt.step()
embedding=bnb.nn.StableEmbedding(64,128)
opt.add_param_group({'params':[embedding.weight]})
x.grad=None
embedding.weight.grad=torch.ones_like(embedding.weight)
opt.step()
dynamic_dtype=str(opt.state[embedding.weight]['state1'].dtype)
fresh()
control_embedding=bnb.nn.StableEmbedding(64,128)
control=LionPlus8bit([control_embedding.weight], **options())
control_embedding.weight.grad=torch.ones_like(control_embedding.weight)
control.step()
results['dynamic_module_override']={
 'expected_native_module_policy':{'optim_bits':32},
 'dynamic_group_momentum_dtype':dynamic_dtype,
 'initial_group_momentum_dtype':str(control.state[control_embedding.weight]['state1'].dtype),
}

results['runtime']={'torch':torch.__version__,'bitsandbytes':bnb.__version__, 'cuda_visible':torch.cuda.is_available()}
(ROOT / 'probe_state_results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
