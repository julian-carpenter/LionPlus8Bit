import copy
import io
import json
import pathlib
import torch
import bitsandbytes as bnb
from lionplus8bit import LionPlus8bit

ROOT=pathlib.Path('/abyss/home/ml/lion_8bit/audit_20261111_fresh/state')
torch.set_num_threads(1)

def equal(a,b):
    if isinstance(a,torch.Tensor): torch.testing.assert_close(a,b,rtol=0,atol=0)
    elif isinstance(a,dict):
        assert a.keys()==b.keys()
        for k in a: equal(a[k],b[k])
    elif isinstance(a,(list,tuple)):
        assert len(a)==len(b)
        for x,y in zip(a,b): equal(x,y)
    else: assert a==b

results=[]
for dtype in (torch.float32,torch.float16,torch.bfloat16):
    for size in (17,4097):
        for split in (1,2):
            bnb.optim.GlobalOptimManager.get_instance().initialize()
            p=torch.nn.Parameter(torch.linspace(-.3,.3,size).to(dtype))
            a=LionPlus8bit([p],clipping='adagc',adagc_warmup_steps=2,max_grad_norm=.5,lr=.0001)
            for t in range(split):
                p.grad=(torch.sin(torch.arange(size)*.01+t)*(t+1)).to(dtype)
                a.step()
            buffer=io.BytesIO();torch.save(a.state_dict(),buffer);buffer.seek(0)
            q=torch.nn.Parameter(p.detach().clone())
            b=LionPlus8bit([q]);b.load_state_dict(torch.load(buffer,weights_only=True,map_location='cpu'))
            for t in range(split,5):
                p.grad=(torch.sin(torch.arange(size)*.01+t)*(t+1)).to(dtype)
                q.grad=p.grad.clone()
                a.step();b.step()
                equal(p,q);equal(a.state_dict(),b.state_dict())
            results.append({'dtype':str(dtype),'size':size,'split':split,'bitwise_equal':True,
                            'history_dtype':str(b._clipping_state.history.dtype),
                            'momentum_dtype':str(b.state[q]['state1'].dtype),
                            'master_dtype':str(b.state[q]['master_weight'].dtype) if 'master_weight' in b.state[q] else None})
(ROOT/'precision_results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
