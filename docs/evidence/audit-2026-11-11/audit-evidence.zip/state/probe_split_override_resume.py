import json
import pathlib
import torch
import bitsandbytes as bnb
from lionplus8bit import LionPlus8bit

root=pathlib.Path('/abyss/home/ml/lion_8bit/audit_20261111_fresh/state')
saved=torch.load(root/'split_override_checkpoint.pt',weights_only=True,map_location='cpu')
manager=bnb.optim.GlobalOptimManager.get_instance()
assert manager.pid2config=={} and manager.index2config=={}
p=torch.nn.Parameter(saved['parameter'])
opt=LionPlus8bit([p])
opt.load_state_dict(saved['optimizer'])
p.grad=torch.ones_like(p)
opt.step()
result={
    'fresh_process':True,
    'effective_lr':opt.get_config(0,0,opt.param_groups[0])['lr'],
    'serialized_overrides':saved['optimizer']['lionplus_config']['overrides'],
    'resumed_parameter':p.item(),
    'expected_uninterrupted_parameter':saved['expected_uninterrupted'],
    'matches_uninterrupted':p.item()==saved['expected_uninterrupted'],
}
(root/'split_override_resume_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
