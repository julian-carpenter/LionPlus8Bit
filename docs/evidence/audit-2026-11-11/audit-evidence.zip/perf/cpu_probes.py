"""Read-only repository probes. CUDA is hidden before Python starts."""
import collections
import copy
import json
import math
import os
from pathlib import Path
import statistics
import sys
from unittest.mock import patch

import torch
from torch.utils._python_dispatch import TorchDispatchMode
import bitsandbytes as bnb
from lionplus8bit import LionPlus8bit
from lionplus8bit import _optimizer as impl
from lionplus8bit import _numerical_guard as guard
from lionplus8bit._clipping import ClippingState

torch.set_num_threads(1)
assert not torch.cuda.is_available()
OUT = Path(__file__).resolve().parent

class Recorder(TorchDispatchMode):
    def __init__(self):
        self.calls = collections.Counter()
        self.scalar_reads = []
        super().__init__()
    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        kwargs = kwargs or {}
        self.calls[str(func)] += 1
        if str(func) == 'aten._local_scalar_dense.default':
            self.scalar_reads.append(str(args[0].dtype))
        return func(*args, **kwargs)

def record_step(pattern):
    params = [torch.nn.Parameter(torch.ones(4096)) for _ in range(4)]
    opt = LionPlus8bit(params, clipping='adagc', adagc_warmup_steps=0,
                      max_grad_norm=100, min_8bit_size=5000, weight_decay=0)
    for p in params:
        p.grad = torch.full_like(p, 0.01)
    opt.step()
    if pattern == 'one_zero':
        params[-1].grad.zero_()
    elif pattern == 'all_zero':
        for p in params: p.grad.zero_()
    elif pattern == 'one_tiny_coordinate':
        params[-1].grad[0] = 1e-30
    counts = collections.Counter()
    sizes = []
    orig_norm, orig_pack, orig_guard, orig_prepare = torch.linalg.vector_norm, ClippingState.pack, impl.tiny_value_flag, impl.prepare_clipping
    def norm(x, *args, **kwargs):
        counts['vector_norm_' + str(kwargs.get('dtype', x.dtype))] += 1
        if kwargs.get('dtype') == torch.float64: sizes.append(x.numel())
        return orig_norm(x, *args, **kwargs)
    def pack(*args, **kwargs):
        counts['packed_cpu_tolist'] += 1
        return orig_pack(*args, **kwargs)
    def tiny(*args, **kwargs):
        counts['guard_scan'] += 1
        return orig_guard(*args, **kwargs)
    def prepare(*args, **kwargs):
        counts['prepare_clipping'] += 1
        return orig_prepare(*args, **kwargs)
    rec = Recorder()
    with patch.object(torch.linalg,'vector_norm',norm), patch.object(ClippingState,'pack',pack), patch.object(impl,'tiny_value_flag',tiny), patch.object(impl,'prepare_clipping',prepare), rec:
        opt.step()
    return {'pattern':pattern,'counts':dict(counts),'fp64_reduction_input_elements':sizes,
            'strict_math':[bool(opt.state[p].get('strict_math',False)) for p in params],
            'torch_op_counts':dict(rec.calls),'cpu_scalar_read_dtypes':rec.scalar_reads,
            'last_clipping':opt.last_clipping}

def guard_probe(count, dtype, strided):
    params=[]
    for _ in range(count):
        p=torch.nn.Parameter(torch.ones(4096,dtype=dtype))
        p.grad=torch.ones(4096,2,dtype=dtype)[:,0] if strided else torch.ones_like(p)
        params.append(p)
    state={p:{'state1':torch.ones_like(p,dtype=torch.float32)} for p in params}
    rec=Recorder()
    with rec:
        flag=guard.tiny_value_flag(params,state,torch.full((count,),1e-20))
    return {'count':count,'dtype':str(dtype),'strided':strided,'flag':int(flag),
            'torch_op_counts':dict(rec.calls),'total_dispatches':sum(rec.calls.values())}

def alias_probe(tiny):
    initial=torch.tensor([1e-30 if tiny else 1.0, 1.0])
    p=torch.nn.Parameter(initial.clone())
    q=torch.nn.Parameter(initial.clone())
    a=LionPlus8bit([p],clipping='adagc',adagc_warmup_steps=0,max_grad_norm=100,betas=(0,0),lr=.1,weight_decay=0)
    b=LionPlus8bit([q],clipping='adagc',adagc_warmup_steps=0,max_grad_norm=100,betas=(0,0),lr=.1,weight_decay=0)
    p.grad=p.detach()
    q.grad=q.detach().clone()
    a.step(); b.step()
    return {'tiny':tiny,'parameter_values':p.tolist(),'expected_parameter_values':q.tolist(),
            'gradient_preserved':torch.equal(p.grad,initial),'aliased_state':a.state[p]['state1'].tolist(),
            'copied_state':b.state[q]['state1'].tolist(),'strict_math':a.state[p].get('strict_math',False)}

result={
 'environment':{'python':sys.version,'torch':torch.__version__,'bnb':bnb.__version__,'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'cuda_available':torch.cuda.is_available(),'implementation':impl.__file__},
 'fallback_counts':[record_step(v) for v in ['ordinary','one_zero','all_zero','one_tiny_coordinate']],
 'eager_guard':[guard_probe(n,d,s) for n in [4,256] for d in [torch.float32,torch.float16] for s in [False,True]],
 'parameter_gradient_alias':[alias_probe(False),alias_probe(True)],
}
(OUT/'cpu_probes.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['fallback_counts','eager_guard']},indent=2))
for x in result['fallback_counts']:
    print('FALLBACK', x['pattern'],x['counts'],'fp64 elements',sum(x['fp64_reduction_input_elements']),'strict',x['strict_math'])
for x in result['eager_guard']:
    print('GUARD',x['count'],x['dtype'],'strided',x['strided'],'dispatches',x['total_dispatches'])
