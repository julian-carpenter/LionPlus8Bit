# Fresh integration review

Reviewed the uncommitted feature branch against baseline `0fb6a57` on 2026-11-12, with the approved training-integration design and plan. Scope: canonical weight layout/state ordering, checkpoint v3, native stream ownership/lifetimes, explicit paging rejection, and reference checkpoint/recovery behavior. Runtime/DDP edits were still being finalized. No repository code was edited and no GPU work was performed.

## Confirmed defect

**P2 — Unwrap only actual framework wrappers when checkpointing models.** `examples/_training_state.py:22-25` treats every object with a `module` child as a DDP wrapper. A valid ordinary model can have a registered child named `module` and additional parameters or buffers. Saving such a model drops those additional values; loading into a fresh instance passes the existing mapping check because it also incorrectly unwraps the target. The helper returns success with an incorrect restored model.

CPU reproduction: an ordinary `torch.nn.Module` containing `self.module = torch.nn.Linear(2, 2)` and `self.extra = torch.nn.Parameter(torch.tensor(7.))` was saved. A fresh equivalent model initialized with `extra = 1` was restored. The load returned success, saved model keys were only `weight`/`bias`, and restored `extra` remained `1` rather than `7`. The probe used SGD to isolate the trainer helper from optimizer behavior. Restrict unwrapping to recognized DDP/DataParallel/compiler wrapper types and cover a normal model with a child named `module`. The restart runner repeats structural unwrapping when collecting its final result and should use the same corrected helper.

## Validation gaps and claim boundaries

- The restart fixture's `local_forwards` buffer currently starts at zero and advances identically on all ranks. It does not exercise the approved case of genuinely different rank-local model buffers. Seed a buffer by logical rank or otherwise make its values different, then verify rollback preserves each rank's values. The checkpoint implementation does save a separate model state for each rank, so this is an evidence gap rather than a demonstrated data-loss bug.
- Component files are fsynced before rename, but the generation directory is not fsynced after the component renames and before manifest publication (`examples/_training_state.py:97-113`). This does not invalidate the promised trainer/worker process-death scope. It does mean the docstring's durability wording must not be read as machine/power-loss durability: a durable new manifest can reference directory entries that were never made durable. Add a generation-directory fsync before publishing if extending that guarantee.
- No confirmed regression was found in the frozen layout/paging core. Supported dense layouts use canonical state allocation, staged native work, original-storage copy-back, and appropriate caller/default-stream dependencies. Checkpoint v3 validates declared state order and group/shape mapping before native loading. Plain checkpoint tensor semantics remain shallow while legacy paging metadata is stripped from copied values.
- Paging correctly rejects eligible CUDA requests before updates and does not label ordinary CPU/subthreshold allocations as managed memory. Its unsupported result is appropriate until allocator ownership and CPU-labelled managed-state arithmetic are solved.
- Current support documentation appropriately keeps native FP8 hardware-blocked on SM75, fullgraph/CUDA-graph capture unsupported, changed-world-size exact replay excluded, and compilation interpreter capture separate from Inductor performance. Positive distributed/restart/compile claims should remain limited to the actual recorded hardware, transport, backend, world-size and fixture combinations; this review did not rerun those GPU experiments.

## CPU verification

Command, from `LionPlus8Bit`:

```bash
CUDA_VISIBLE_DEVICES='' \
PYTHONPATH=/tmp/lionplus-adagc-dev:/abyss/home/ml/lion_8bit/verification_20261111/deps:src \
python -m pytest -q tests/test_weight_layouts.py tests/test_paging.py tests/test_training_restart.py -k 'not controlled_trainer'
```

Result: **181 passed, 8 skipped in 9.16 seconds**. GPU cases remained unavailable by design. The controlled trainer subprocess test was excluded because the coordinator owns the integration experiments. The independent CPU model-unwrapping probe reproduced the confirmed defect above.
