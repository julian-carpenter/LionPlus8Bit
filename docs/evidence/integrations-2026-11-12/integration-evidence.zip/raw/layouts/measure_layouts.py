"""Matched layout staging benchmark; correctness matrix is in pytest logs."""
import gc
import hashlib
import json
from pathlib import Path
import statistics
import time
import torch
import bitsandbytes as bnb
from lionplus8bit import LionPlus8bit

ROOT = Path('/abyss/home/ml/lion_8bit/LionPlus8Bit')
DEST = Path('/abyss/home/ml/lion_8bit/integrations_20261112/layouts/measurements.json')
if DEST.exists():
    raise SystemExit('Refusing to overwrite measurements')
torch.cuda.set_device(0)

@torch.no_grad()
def measure(arm, bits):
    parameters = [torch.nn.Parameter(torch.ones((1024, 512), device='cuda').t()) for _ in range(2)]
    if arm != 'staged':
        parameters = [torch.nn.Parameter(p.detach().contiguous()) for p in parameters]
    for p in parameters:
        p.grad = torch.linspace(-1, 1, p.numel(), device='cuda').reshape(p.shape)
    if arm == 'pytorch-fp32-lion':
        momentum = [torch.zeros_like(p) for p in parameters]
        def step():
            norms = torch._foreach_norm([p.grad for p in parameters], 2, dtype=torch.float32)
            scale = min(1., 4. / float(torch.linalg.vector_norm(torch.stack(norms))))
            for p, m in zip(parameters, momentum):
                g = p.grad * scale
                direction = (m * .95 + g * .05).sign()
                m.mul_(.98).add_(g, alpha=.02)
                p.add_(direction, alpha=-5e-5)
    else:
        optimizer = LionPlus8bit(parameters, weight_decay=0, min_8bit_size=0 if bits == 8 else 10**9)
        step = optimizer.step
    for _ in range(100):
        step()
    torch.cuda.synchronize()
    resident = torch.cuda.memory_allocated()
    torch.cuda.reset_peak_memory_stats()
    started = time.perf_counter()
    for _ in range(300):
        step()
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    peak = torch.cuda.max_memory_allocated()
    digest = float(parameters[0].flatten()[0])
    result = dict(arm=arm, momentum_bits=32 if arm == 'pytorch-fp32-lion' else bits,
                  warmup=100, timed_steps=300, latency_ms=elapsed / 300 * 1000,
                  allocated_bytes=resident, transient_peak_bytes=peak-resident,
                  first_weight_after_400_steps=digest)
    del step, parameters
    gc.collect()
    torch.cuda.empty_cache()
    return result

records=[]
for bits in (8, 32):
    arms=['contiguous', 'staged', 'pytorch-fp32-lion']
    for rep in range(3):
        for arm in arms[rep:] + arms[:rep]:
            result=measure(arm, bits)
            records.append(dict(repetition=rep, **result))
            print(json.dumps(records[-1]), flush=True)
summary={}
for bits in (8,32):
    by_arm={arm: [r['latency_ms'] for r in records if r['momentum_bits']==bits and r['arm']==arm]
            for arm in ('contiguous','staged')}
    ratios=[s/c for s,c in zip(by_arm['staged'],by_arm['contiguous'])]
    summary[str(bits)] = dict(median_ms={k:statistics.median(v) for k,v in by_arm.items()},
                             paired_staging_overhead_percent=[100*(r-1) for r in ratios])
result=dict(status='measured-mode-cost-only', device=torch.cuda.get_device_name(), torch=torch.__version__,
            bitsandbytes=bnb.__version__, tensor_shapes=[[512,1024]]*2, records=records, summary=summary,
            note='No speedup or pre-change baseline regression claim. PyTorch control uses FP32 momentum.',
            source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                           for p in (ROOT/'src/lionplus8bit/_optimizer.py', ROOT/'src/lionplus8bit/_layout.py')})
DEST.write_text(json.dumps(result,indent=2)+'\n')
