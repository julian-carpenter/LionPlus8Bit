import os,subprocess,sys
from pathlib import Path
import torch
if len(sys.argv)>1:
 from lionplus8bit import LionPlus8bit
 torch.set_num_threads(1)
 outputs=[]
 for seed in (17,29,43):
  torch.manual_seed(seed)
  p=torch.nn.Parameter(torch.randn(4097))
  opt=LionPlus8bit([p],clipping='adagc',max_grad_norm=.4)
  for t in range(200):
   p.grad=torch.randn_like(p)*(.1 if t%17 else 10)
   if t==111:p.grad[0]=1e-35
   opt.step()
  outputs.append(dict(weights=p.detach(),native=opt.state[p],history=opt._clipping_state.history,ready=opt._clipping_state.initialized,exceptions=opt._clipping_state.exceptions,steps=opt._clipping_state.steps))
 torch.save(outputs,sys.argv[1])
else:
 root=Path(__file__).parent
 for label,src in [('old','/tmp/lionplus-baseline-0fb6a57/src'),('current','/abyss/home/ml/lion_8bit/LionPlus8Bit/src')]:
  env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONPATH=src+':/tmp/lionplus-adagc-dev:/abyss/home/ml/lion_8bit/verification_20261111/deps')
  subprocess.run([sys.executable,__file__,str(root/f'contiguous-{label}.pt')],env=env,check=True)
 def equal(a,b):
  if isinstance(a,torch.Tensor):assert torch.equal(a,b)
  elif isinstance(a,dict):
   assert a.keys()==b.keys()
   for k in a:equal(a[k],b[k])
  elif isinstance(a,list):
   for x,y in zip(a,b):equal(x,y)
  else:assert a==b
 equal(torch.load(root/'contiguous-old.pt',weights_only=False),torch.load(root/'contiguous-current.pt',weights_only=False))
 print('Three-seed 200-step contiguous replay matches baseline bitwise, including strict path and warmup.')
