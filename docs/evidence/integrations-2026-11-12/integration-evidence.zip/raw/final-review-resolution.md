# Independent review resolutions

The original `final-review.md` is retained unchanged. The final implementation and evidence resolve its findings as follows.

- **P2 ordinary child named module:** `examples/_training_state.py:_base_model` unwraps only recognized DDP/DataParallel/compiler wrappers. `test_normal_child_named_module_keeps_outer_parameters_and_buffers` preserves ordinary outer parameters and buffers; red and green runtime regression logs are retained. The restart runner uses the same helper.
- **Rank-local buffers:** `local_rank_marker` differs by logical rank. Four-rank CUDA rollback, channels-last rollback and two-rank remap/transposed recovery compare each rank's buffer and next RNG values. This addresses the evidence gap without assuming DDP buffer broadcasts equalize checkpoint state.
- **Generation directory fsync:** component renames are followed by generation-directory fsync before manifest publication. A syscall-order regression checks this ordering. The public claim remains controlled process-failure rollback, not universal filesystem/power-loss behavior.
- **Semantic component-load errors:** CPU snapshots permit collective rollback of model/optimizer/scaler/scheduler and RNG when a public loader rejects state after mutation. Focused integrity/load controls and the complete suites pass.
- **Layout/paging:** no core regression was confirmed by the reviewer; final CUDA stream/layout tests and full regressions pass. Eligible managed paging remains refused at its ownership prerequisite.

Final expanded verification: 401 CUDA-required tests and 334 installed-wheel CPU tests passed, each with 15 subtests; six independent CUDA groups passed. Raw failures (including FP16 compiler numerical failures) are not reclassified as passes by these regressions. See the validation report for feature-specific scope and the archive's source snapshot for reviewed code.
