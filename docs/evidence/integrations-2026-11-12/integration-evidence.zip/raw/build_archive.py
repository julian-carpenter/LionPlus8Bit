from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile

root=Path('/abyss/home/ml/lion_8bit/LionPlus8Bit')
raw=root.parent/'integrations_20261112'
stage=Path('/tmp/lionplus-integration-evidence-final-20261112')
stage.mkdir(exist_ok=False)
dest=root/'docs/evidence/integrations-2026-11-12'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base='0fb6a5742c6b27e4445e05b401410d6083c45190'
subprocess.run(['git','archive','--format=tar.gz','-o',str(stage/'baseline-source-0fb6a57.tar.gz'),base,'src','tests','tools','examples','README.md','pyproject.toml','LICENSE','.github'],cwd=root,check=True)
ignored={'__pycache__','.pytest_cache','.ruff_cache'}
def ignore(directory,names):
 return [n for n in names if n in ignored or n.startswith('compiler-cache-') or n.startswith('torchinductor')]
shutil.copytree(raw,stage/'raw',ignore=ignore)
paths=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z'],cwd=root).decode().split('\0')
roots=('src/','tests/','tools/','examples/','.github/')
extra={'README.md','pyproject.toml','LICENSE','.gitignore','MANIFEST.in','docs/validation-integrations.md','docs/integration-progress.md','docs/superpowers/plans/2026-11-12-training-integrations.md','docs/superpowers/specs/2026-11-12-training-integrations-design.md','docs/evidence/integrations-2026-11-12/README.md'}
for rel in paths:
 if rel and (rel.startswith(roots) or rel in extra):
  source=root/rel
  if source.is_file():
   target=stage/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
(stage/'source/SOURCE_BASE').write_text(base+'\n')
source_hashes={str(p.relative_to(stage/'source')):sha(p) for p in sorted((stage/'source').rglob('*')) if p.is_file()}
(stage/'source/source_hashes.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
# Verify every historical evidence file against its original Git blob.
old=[]
entries=subprocess.check_output(['git','ls-tree','-r','-z',base,'docs/evidence'],cwd=root).split(b'\0')
for entry in entries:
 if not entry:continue
 meta,rel=entry.split(b'\t',1);mode,kind,blob=meta.split();p=root/rel.decode();data=p.read_bytes()
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob.decode(),p
 old.append({'path':rel.decode(),'git_blob':blob.decode(),'sha256':sha(p)})
(stage/'preserved_evidence_hashes.json').write_text(json.dumps(old,indent=2)+'\n')
files=[p for p in sorted(stage.rglob('*')) if p.is_file()]
(stage/'MANIFEST.sha256').write_text(''.join(sha(p)+'  '+str(p.relative_to(stage))+'\n' for p in files))
archive=dest/'integration-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(stage.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(stage)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 manifest=z.read('MANIFEST.sha256').decode().splitlines()
 for line in manifest:
  digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
(dest/'SHA256SUMS').write_text(sha(archive)+'  integration-evidence.zip\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':len(files)+1,'sha256':sha(archive),'prior_evidence_files_unchanged':len(old)}))
